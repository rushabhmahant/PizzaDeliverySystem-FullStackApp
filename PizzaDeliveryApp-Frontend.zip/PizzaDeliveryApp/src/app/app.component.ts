import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pizza Delivery System';

  customerId!: number;

  setCustomerId(customerId: number){
    this.customerId = customerId;
  }

  getCustomerId(): number{
    return this.customerId;
  }

}
