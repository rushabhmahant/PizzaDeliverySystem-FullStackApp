import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { Customer } from '../customer';
import { Order } from '../order';
import { CustomerService } from '../customer.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { OrderService } from '../order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {

  customerId!: number;
  customer = new Customer();
  order = new Order();

  orderForm!: FormGroup;

  constructor(private appComponent: AppComponent, private customerService: CustomerService,
    private formBuilder: FormBuilder, private orderService: OrderService, private router: Router) { }

  ngOnInit(): void {

    this.orderForm = this.formBuilder.group({
      category: '',
      name: '',
      size: ''
    });

    
    console.log("CustomerId received: ");
    console.log(this.appComponent.getCustomerId());
    this.customerId = this.appComponent.getCustomerId();

    this.customerService.getCustomerById(this.customerId).subscribe(
      data => this.customer = data,
      error => console.log("ERROR")
    );

  }

  placeOrder(){
    if(this.order.pizzaSize == "Regular"){
      this.order.orderPrice = 500;
    }
    else if(this.order.pizzaSize == "Medium"){
      this.order.orderPrice = 1000;
    }
    else{
      this.order.orderPrice = 1500;
    }
    this.order.customerId = this.customer.customerId;
    this.order.orderDate = new Date();
    this.order.orderStatus = "Order placed";

    console.log(this.order.pizzaCategory);
    console.log(this.order);
    this.orderService.placeOrder(this.order).subscribe(
      data => {alert("Order placed successfully, your bill amount is Rs. " + this.order.orderPrice);
      this.router.navigate(['customerOrders', this.customerId]);
    },
      error => console.log(error)
    );
  }

}
