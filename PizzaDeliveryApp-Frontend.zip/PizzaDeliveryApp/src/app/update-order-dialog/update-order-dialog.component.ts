import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-update-order-dialog',
  templateUrl: './update-order-dialog.component.html',
  styleUrls: ['./update-order-dialog.component.css']
})
export class UpdateOrderDialogComponent implements OnInit {

  selectedValue: string = '';
  orderId!: number;

  constructor(private orderService: OrderService,
    private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {

    this.activatedRoute.paramMap.subscribe(params => { 
      console.log("params: " + params);
      console.log("Number here: "+params.get("orderId"));
      this.orderId = Number(params.get("orderId")); 
      this.selectedValue = String(params.get("orderStatus"));
  });

  }

  updateStatus(selectedValue: string){
    console.log("Updating status of orderID " +this.orderId+ " to: " + this.selectedValue)
    this.orderService.updateOrderStatus(this.orderId, this.selectedValue).subscribe(
      data => {alert("Order status updated successfully");
      this.goToOrderList();
    },
      error => console.log("Error while updating order status: " + error)
    );
  }

  goToOrderList(){
      this.router.navigate(['/getOrders']);
  }

}
