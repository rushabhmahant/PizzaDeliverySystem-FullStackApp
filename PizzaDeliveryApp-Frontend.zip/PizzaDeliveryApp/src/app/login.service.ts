import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  baseUrl: string = "http://localhost:8001/customer";

  constructor(private httpClient: HttpClient) { }

  login(customer: Customer): Observable<Customer>{
    console.log("Logging in customer: " + customer);
    return this.httpClient.post<Customer>(this.baseUrl + "/login", customer);
  }

  signup(customer: Customer): Observable<Object>{
    return this.httpClient.post<Object>(this.baseUrl + "/addCustomer", customer);
  }

}
