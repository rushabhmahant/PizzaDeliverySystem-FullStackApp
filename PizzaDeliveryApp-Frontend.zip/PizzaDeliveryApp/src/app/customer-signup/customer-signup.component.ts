import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-customer-signup',
  templateUrl: './customer-signup.component.html',
  styleUrls: ['./customer-signup.component.css']
})
export class CustomerSignupComponent implements OnInit {

  customer = new Customer();

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit(): void {
  }

  customerRegister(){
    this.loginService.signup(this.customer).subscribe(
      data => {alert("User Registered");
    this.router.navigate(['login'])},
      error => console.log(error)
    );
    
  }

}
