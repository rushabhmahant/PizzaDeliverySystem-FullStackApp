import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {

  orders!: Order[];

  constructor(private orderService: OrderService,
    private router: Router) { }

  ngOnInit(): void {
    this.getOrders();
  }

  getOrders(){
    this.orderService.getOrdersList().subscribe(
      data => this.orders = data,
      error => console.log("Error while fetching orders: " + error)
    );
  }

  goToUpdateOrderStatus(orderId: number, orderStatus: string){
    this.router.navigate(['updateOrderStatus', orderId, orderStatus]);
  }

}
