import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-customer-orders',
  templateUrl: './customer-orders.component.html',
  styleUrls: ['./customer-orders.component.css']
})
export class CustomerOrdersComponent implements OnInit {

  customerId!: number;
  orders!: Order[];
  customer = new Customer();

  constructor(private activatedRoute: ActivatedRoute, private orderService: OrderService,
    private customerService: CustomerService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params => { 
      console.log("params: " + params);
      console.log("Number here: "+params.get("customerId"));
      this.customerId = Number(params.get("customerId")); 
  });

    this.orderService.getCustomerOrders(this.customerId).subscribe(
      data => this.orders = data,
      error => console.log(error)
    );

    this.customerService.getCustomerById(this.customerId).subscribe(
      data => this.customer = data,
      error => console.log(error)
    );

  }

}
