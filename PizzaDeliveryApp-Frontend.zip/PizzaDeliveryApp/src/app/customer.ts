export class Customer {

    customerId!: number;
	customerName!: string;
	customerEmailId!: string;
	customerPassword!: string;
	customerMobileNo!: number;
	customerAddress!: string;

}
