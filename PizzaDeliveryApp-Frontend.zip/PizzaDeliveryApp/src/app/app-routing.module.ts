import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerOrdersComponent } from './customer-orders/customer-orders.component';
import { CustomerSignupComponent } from './customer-signup/customer-signup.component';
import { OrderListComponent } from './order-list/order-list.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateOrderDialogComponent } from './update-order-dialog/update-order-dialog.component';

const routes: Routes = [
  {path: 'getCustomers', component: CustomerListComponent},
  {path: 'addCustomer', component: CreateCustomerComponent},
  {path: 'updateCustomer/:customerId', component: UpdateCustomerComponent},
  {path: 'getOrders', component: OrderListComponent},
  {path: 'updateOrderStatus/:orderId/:orderStatus', component: UpdateOrderDialogComponent},
  {path: 'login', component: CustomerLoginComponent},
  {path: 'signup', component: CustomerSignupComponent},
  {path: 'customerOrders/:customerId', component: CustomerOrdersComponent},
  {path: 'placeOrder/:customerId', component: PlaceOrderComponent},
  {path: '', redirectTo: 'login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
