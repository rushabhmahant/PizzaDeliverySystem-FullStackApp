import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {

  customers!:Customer[];
  loggedCustomerId!: string

  constructor(private customerService: CustomerService,
    private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getCustomers();

    this.activatedRoute.paramMap.subscribe(params => { 
      console.log("params: " + params);
      console.log("Number here: "+params.get("customerId"));
      this.loggedCustomerId = (params.get("customerId"))!; 
  });

  }

  private getCustomers(){
    this.customerService.getCustomerList().subscribe(data => {
      this.customers = data
    })
  }

  goToUpdateCustomer(customerId: number){
    this.router.navigate(['/updateCustomer', customerId]);
  }

  goToCustomerOrders(customerId: number){
    this.router.navigate(['/customerOrders', customerId]);
  }

  deleteCustomer(customerId: number, customerName: string){
    if(confirm("Delete Customer "+ customerName+"?")){
    this.customerService.deleteCustomer(customerId).subscribe(
      data => {console.log("Customer deleted successfully");
      this.reloadList();
    },
      error => ("Error! " + error)
    );

  }
}

reloadList(){
  window.location.reload();
}

}
