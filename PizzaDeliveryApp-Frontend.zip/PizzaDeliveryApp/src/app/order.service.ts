import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private httpClient: HttpClient) { }

  //  Resolve the CORS issue and use the base baseUrl
  private baseUrl = "http://localhost:9191/order"

  getOrdersList(): Observable<Order[]>{
    return this.httpClient.get<Order[]>(`${this.baseUrl + "/getAllOrders"}`);
  }

  updateOrderStatus(orderId: number, orderStatus: string): Observable<Order>{
    let queryParams = new HttpParams();
    queryParams = queryParams.append("status",orderStatus);
    return this.httpClient.put<Order>("http://localhost:8002/order/" + orderId + "/updateorderstatus", '', {params:queryParams});
  }

  getCustomerOrders(customerId: number): Observable<Order[]>{
    return this.httpClient.get<Order[]>("http://localhost:8002/order/customer/"+customerId);
  }

  placeOrder(order: Order): Observable<Order>{
    return this.httpClient.post<Order>("http://localhost:8002/order/placeorder", order);
  }
}
