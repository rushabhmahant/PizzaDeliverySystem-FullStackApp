export class Order {

    orderId!: number;
	customerId!: number;
	pizzaName!: string;
	pizzaCategory!: string;
	pizzaSize!: string;
	orderPrice!: number;
	orderDate!: Date;
	orderStatus!: string;

}
