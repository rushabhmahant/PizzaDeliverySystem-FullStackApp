import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Customer } from '../customer';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {

  customer = new Customer();

  constructor(private loginService: LoginService,
    private router: Router, private appComponent: AppComponent) { }

  ngOnInit(): void {
  }

  customerLogin(){
    console.log(this.customer);
    this.loginService.login(this.customer).subscribe(data => 
      {
        console.log(data);
        this.customer = data;
        this.appComponent.setCustomerId(this.customer.customerId);
        alert("Logged in successfully");
        this.router.navigate(['getCustomers']);
      },
      error => 
      {
        console.log(error.error);
        alert("Incorrect Email id or password");
      });
  }

}
