import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})
export class CreateCustomerComponent implements OnInit {

  customer: Customer = new Customer();
  alertMsg: string = "Customer Details saved successfully";

  constructor(private customerService: CustomerService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    console.log(this.customer);
    this.saveCustomer();
  }

  saveCustomer(){
    this.customerService.addCustomer(this.customer).subscribe( data =>{
      console.log("Data received: " + data);
      this.goToCustomerList();
    },
      error => console.log(error)
    );
  }

  alertUser(alertMsg:string){
    alert(this.alertMsg);
  }

  goToCustomerList(){
    this.router.navigate(['/getCustomers']);
  }

}
