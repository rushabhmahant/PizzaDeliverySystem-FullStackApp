import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  //  Resolve the CORS issue and use the base baseUrl
  private baseUrl = "http://localhost:9191/customer"

  constructor(private httpClient: HttpClient) { }

  getCustomerList(): Observable<Customer[]>{
    return this.httpClient.get<Customer[]>(`${this.baseUrl + "/getCustomers"}`);
  }

  getCustomerById(id: number): Observable<Customer>{
    return this.httpClient.get<Customer>(`${"http://localhost:8001/customer/getCustomer/"+id}`);
  }

  addCustomer(customer: Customer): Observable<Customer>{
    return this.httpClient.post<Customer>(`${"http://localhost:8001/customer/addCustomer"}`, customer);
  }

  updateCustomer(customerId: number, customer: Customer): Observable<Customer>{
    return this.httpClient.put<Customer>(`${"http://localhost:8001/customer/updateCustomer/" + customerId}`, customer);
  }

  deleteCustomer(customerId: number){
    return this.httpClient.delete(`${"http://localhost:8001/customer/deleteCustomer/" + customerId}`);
  }

}
