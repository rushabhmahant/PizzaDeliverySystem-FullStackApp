import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  customer = new Customer();
  customerId!: number;

  constructor(private customerService: CustomerService,
    private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    //this.customerId = this.activatedRoute.snapshot.params['customerId'];
    //this.customerId = this.activatedRoute.snapshot.paramMap.get("customerId");
    this.activatedRoute.paramMap.subscribe(params => { 
      console.log("params: " + params);
      console.log("Number here: "+params.get("customerId"));
      this.customerId = Number(params.get("customerId")); 
  });

    this.customerService.getCustomerById(this.customerId).subscribe(
      data => this.customer = data,
      error => console.log("Error! " + error)
    );
  }

  onSubmit(){
    this.customerService.updateCustomer(this.customerId, this.customer).subscribe(
      data => {alert("Customer details updated");
              this.goToCustomerList();
    },
      error => console.log("Error! " + error)
    );
  }

  goToCustomerList(){
    this.router.navigate(['/getCustomers']);
  }

}
